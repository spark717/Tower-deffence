﻿Terms and Conditions
- Fonts are free for personal and non-profit projects.
- Personal works displayed online using the fonts must provide the font source.
- A commercial license is needed for any work made to generate income.

Commercial License
- The license is granted for lifetime, for any kind of project, worldwide, for one individual/company.
- The license is non-exclusive, royaly-free and non-transferable.
- The license can be purchased from www.loremipsum.ro.

Notes
- The payment receipt proves you a legitimate user of the font.
- The copyright free font is sent to your email address.
- For questions or requests write to levi@loremipsum.ro

Thank you, 
Levi
